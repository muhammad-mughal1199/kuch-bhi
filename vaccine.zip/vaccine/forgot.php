<?php
  // Connect to the MySQL database
  $conn = mysqli_connect('localhost', 'root', '', 'user_db');

  // Check if the connection was successful
  if (!$conn) {
    die('Connection failed: '. mysqli_connect_error());
  }
?>

<link rel="stylesheet" href="style_login.css">
<form action="" method="POST">
<center>
<h1>Reset Password </h1>
</center><br>
<label>Email:</label>
  <input type="email" name="email" required>

  <label>Username:</label>
  <input type="text" name="name" required>
  <br>
  <label>New Password:</label>
  <input type="password" name="new_password" required>
  <br>

  <button type="submit">Reset Password</button>

<?php 
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $new_password = $_POST['new_password'];

        $res = "SELECT name, email FROM users WHERE name='$name' AND email='$email'"; 
        $result = mysqli_query($conn, $res);

        if (mysqli_num_rows($result) > 0) {
            $change = "UPDATE users SET password='$new_password' WHERE name='$name' AND email='$email'";
            if (mysqli_query($conn, $change)) {
                echo "Password reset successfully!";
                header("Location: login.php");
            } else {
                echo "Error: ". mysqli_error($conn);
            }
        } else {
            echo "User not found!";
        }
    }
?>